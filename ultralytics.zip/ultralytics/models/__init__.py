# Ultralytics YOLO 🚀, AGPL-3.0 license

from .yolo import YOLO

__all__ = "YOLO"  # allow simpler import
